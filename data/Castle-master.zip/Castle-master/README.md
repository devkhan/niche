# Castle
A comparative analysis of synthetic lethal sets of genes/reactions in metabolic networks of different organisms through Flux Balance Analysis(FBA) via COBRApy.
