import cobra.io, json, os, multiprocessing
from multiprocessing import Pool
from cobra.solvers import solver_dict, get_solver_name

listDir = os.listdir('../models')

def worker(fileName):
	# Uncomment to print number of processors being used
	# print(multiprocessing.cpu_count())

	cobraModel = cobra.io.load_json_model('../models/' + fileName)
	x_dict = cobraModel.optimize().x_dict
	maxi = cobraModel.solution.f

	# Called by value
	reactionList = cobraModel.reactions[:]
	reactionList = cutDown(fileName, reactionList, cobraModel, x_dict)

	data = double_reaction_deletion(cobraModel, cobraModel.reactions[:], reactionList, maxi, fileName)
	with open('../data/Lethal Reactions/Double Lethals/' + fileName, 'w') as handle:
		json.dump(data, handle, sort_keys=True, indent=4)

	print("Done " + str(fileName))

def cutDown(fileName, reactions, model, xDict):
	with open("../data/Ignore Set/" + fileName) as ignoreSetFile:
	    ignoreSet = json.load(ignoreSetFile)

	with open("../data/Lethal Reactions/Single Lethals/" + fileName) as singleLethalsFile:
	    singleLethals = json.load(singleLethalsFile)

	zeroFluxSet = {}
	for key in xDict:
		if xDict[key] == 0.0:
			zeroFluxSet[key] = xDict[key]

	for key in ignoreSet:
		if key in reactions:
			reactions.remove(model.reactions.get_by_id(key))

	for key in singleLethals[0]:
		if key in reactions:
			try:
				reactions.remove(model.reactions.get_by_id(key))
			except:
				del reactions[key]

	for key in zeroFluxSet:
		if key in reactions:
			reactions.remove(model.reactions.get_by_id(key))

	return reactions

def double_reaction_deletion(model, allReactions, reactions, maximum, fileName, solver=None, **solver_args):
	solver = solver_dict[get_solver_name() if solver is None else solver]
	lp = solver.create_problem(model)
	growth_rate_dict = {}
	status_dict = {}
	index = 1
	flag = 0

	for reaction1 in reactions:
		old_bounds1 = (reaction1.lower_bound, reaction1.upper_bound)
		index1 = model.reactions.index(reaction1)
		solver.change_variable_bounds(lp, index1, 0., 0.)
		solver.solve_problem(lp, **solver_args)

		reaction2 = reactions[:]
		try:
			x_dict = solver.format_solution(lp, model).x_dict
			allReactionsNew = allReactions[:]
			reactions2 = cutDown(fileName, allReactionsNew, model, x_dict)
		except:
			pass

		for reaction2 in reactions2:
			for key in growth_rate_dict:
				#print(reaction1.id, growth_rate_dict[key][1], reaction2.id, growth_rate_dict[key][0])
				if reaction1.id in growth_rate_dict[key] and reaction2.id in growth_rate_dict[key]:
					flag = 1
					break
				else:
					flag = 0
			if flag == 0:
				old_bounds2 = (reaction2.lower_bound, reaction2.upper_bound)
				index2 = model.reactions.index(reaction2)
				solver.change_variable_bounds(lp, index2, 0., 0.)
				solver.solve_problem(lp, **solver_args)

				# get the status and growth rate
				if solver.get_objective_value(lp) <= (0.01*maximum):
					status = solver.get_status(lp)
					status_dict[index] = reaction1.id, reaction2.id, status
					growth_rate_dict[index] = reaction1.id, reaction2.id, solver.get_objective_value(lp) \
						if status == "optimal" else 0.0
					index = index + 1

				# reset the problem
				solver.change_variable_bounds(lp, index2, old_bounds2[0], old_bounds2[1])
		solver.change_variable_bounds(lp, index1, old_bounds1[0], old_bounds1[1])
	return (growth_rate_dict, status_dict)

def pool(noOfProcesses, fileName):
	p = Pool(processes = noOfProcesses)
	p.map(worker, fileName)

if __name__ == '__main__':
	print("Pool started!")
	pool(3, listDir)