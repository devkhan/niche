import cobra.io, json, os, multiprocessing
from multiprocessing import Pool
from cobra.solvers import solver_dict, get_solver_name
from warnings import warn
from itertools import chain, product

from six import iteritems, string_types
import numpy

from cobra.manipulation.delete import find_gene_knockout_reactions, \
    get_compiled_gene_reaction_rules
from cobra.flux_analysis.deletion_worker import CobraDeletionPool, CobraDeletionMockPool

listDir = os.listdir('../models')

def worker(fileName):
    #Uncomment to print number of processors being used
    #print(multiprocessing.cpu_count())

    cobraModel = cobra.io.load_json_model('../models/' + fileName)
    x_dict = cobraModel.optimize().x_dict
    maxi = cobraModel.solution.f

    # Called by value
    geneList = cobraModel.genes[:]
    reactionList = cobraModel.reactions[:]
    reactionList = cutDown(fileName, reactionList, cobraModel, x_dict)

    data = double_gene_deletion(cobraModel, geneList, maxi, reactionList)
    with open('../data/Lethal Genes/Double Lethals/' + fileName, 'w') as handle:
        json.dump(data, handle, sort_keys=True, indent=4)

    print("Done " + str(fileName))

def cutDown(fileName, reactions, model, xDict):
    with open("../data/Ignore Set/" + fileName) as ignoreSetFile:
        ignoreSet = json.load(ignoreSetFile)

    with open("../data/Lethal Reactions/Single Lethals/" + fileName) as singleLethalsFile:
        singleLethals = json.load(singleLethalsFile)

    for key in ignoreSet:
        if key in reactions:
            reactions.remove(model.reactions.get_by_id(key))

    for key in singleLethals[0]:
        if key in reactions:
            try:
                reactions.remove(model.reactions.get_by_id(key))
            except:
                del reactions[key]

    return reactions

def double_gene_deletion(model, genes, maximum, reactions, solver=None, **solver_args):

    solver = solver_dict[get_solver_name() if solver is None else solver]
    lp = solver.create_problem(model)
    growth_rate_dict = {}
    status_dict = {}
    index = 1
    flag = 0

    for gene1 in genes:
        old_bounds1 = {}
        for reaction1 in find_gene_knockout_reactions(model, [gene1]):
            index1 = model.reactions.index(reaction1)
            old_bounds1[index1] = (reaction1.lower_bound, reaction1.upper_bound)
            if reaction1 in reactions:
                flag = 0
                solver.change_variable_bounds(lp, index1, 0., 0.)
            else:
                flag = 1
                break

        for gene2 in genes:
            old_bounds2 = {}
            for reaction2 in find_gene_knockout_reactions(model, [gene2]):
                index2 = model.reactions.index(reaction2)
                old_bounds2[index2] = (reaction2.lower_bound, reaction2.upper_bound)
                if reaction2 in reactions:
                    flag = 0
                    solver.change_variable_bounds(lp, index2, 0., 0.)
                else:
                    flag = 1
                    break

            if flag == 0:
                solver.solve_problem(lp, **solver_args)

                # get the status and growth rate
                if solver.get_objective_value(lp) <= (0.01*maximum):
                    status = solver.get_status(lp)                                                                                                                                      
                    status_dict[index] = gene1.id, gene2.id, status
                    growth_rate = solver.get_objective_value(lp) \
                        if status == "optimal" else 0.
                    growth_rate_dict[index] = gene1.id, gene2.id, growth_rate
                    index = index + 1
                
            # reset the problem
            for index2, bounds in iteritems(old_bounds2):
                solver.change_variable_bounds(lp, index2, bounds[0], bounds[1])
        for index1, bounds in iteritems(old_bounds1):
            solver.change_variable_bounds(lp, index1, bounds[0], bounds[1])
    return (growth_rate_dict, status_dict)

def pool(noOfProcesses, fileName):
    p = Pool(processes = noOfProcesses)
    p.map(worker, fileName)

if __name__ == '__main__':
    print("Pool started!")
    pool(3, listDir)