import cobra.io, json, os
from cobra.solvers import solver_dict, get_solver_name

listDir = os.listdir('../models')

for i in range (0, len(listDir)):
	dic = {}
	with open("../models/" + listDir[i]) as data_file:
	    jsonData = json.load(data_file)

	model = cobra.io.load_json_model('../models/' + listDir[i])

	data = model.optimize().x_dict

	for j in data.items():
		if j[1] == 0.0:
			dic[j[0]] = j[1]

	with open('../data/Zero Flux Set/' + listDir[i], 'w') as handle:
		json.dump(dic, handle, sort_keys=True, indent=4)