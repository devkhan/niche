import cobra.io, json, os, multiprocessing
from multiprocessing import Pool
from cobra.solvers import solver_dict, get_solver_name
from cobra.manipulation.delete import find_gene_knockout_reactions
from six import iteritems

listDir = os.listdir('../models')

def worker(fileName):
    # Uncomment to print number of processors being used
    # print(multiprocessing.cpu_count())

    cobraModel = cobra.io.load_json_model('../models/' + fileName)
    x_dict = cobraModel.optimize().x_dict
    maxi = cobraModel.solution.f

    # Called by value
    #reactionListFull = cobraModel.reactions[:]
    #reactionList = cutDown(fileName, reactionListFull, cobraModel, x_dict)
    geneList = cobraModel.genes[:]

    data = single_gene_deletion(cobraModel, geneList, maxi)
    with open('../data/Lethal Genes/Single Lethals/' + fileName, 'w') as handle:
        json.dump(data, handle, sort_keys=True, indent=4)

def cutDown(fileName, reactions, model, xDict):
    with open("../data/Ignore Set/" + fileName) as ignoreSetFile:
        ignoreSet = json.load(ignoreSetFile)

    zeroFluxSet = {}
    for key in xDict:
        if xDict[key] == 0.0:
            zeroFluxSet[key] = xDict[key]

    for key in ignoreSet:
        if key in reactions:
            reactions.remove(model.reactions.get_by_id(key))

    for key in zeroFluxSet:
        if key in reactions:
            reactions.remove(model.reactions.get_by_id(key))

    return reactions

def single_gene_deletion(model, genes, maximum, solver=None, **solver_args):
    solver = solver_dict[get_solver_name() if solver is None else solver]
    lp = solver.create_problem(model)
    growth_rate_dict = {}
    status_dict = {}
    for gene in genes:
        old_bounds = {}
        for reaction in find_gene_knockout_reactions(model, [gene]):
            index = model.reactions.index(reaction)
            old_bounds[index] = (reaction.lower_bound, reaction.upper_bound)
            solver.change_variable_bounds(lp, index, 0., 0.)
        solver.solve_problem(lp, **solver_args)
        # get the status and growth rate
        if solver.get_objective_value(lp) <= (0.01*maximum):
            status = solver.get_status(lp)
            status_dict[gene.id] = status
            growth_rate = solver.get_objective_value(lp) \
                if status == "optimal" else 0.
            growth_rate_dict[gene.id] = growth_rate
        # reset the problem
        for index, bounds in iteritems(old_bounds):
            solver.change_variable_bounds(lp, index, bounds[0], bounds[1])
    return (growth_rate_dict, status_dict)

def pool(noOfProcesses, fileName):
    p = Pool(processes = noOfProcesses)
    p.map(worker, fileName)

if __name__ == '__main__':
    print("Pool started!")
    pool(3, listDir)