import cobra.io, json, os, multiprocessing
from multiprocessing import Pool
from cobra.solvers import solver_dict, get_solver_name

listDir = os.listdir('../models')

def worker(fileName):
	# Uncomment to print number of processors being used
	print(multiprocessing.cpu_count())

	cobraModel = cobra.io.load_json_model('../models/' + fileName)

	# Called by value
	data = {}
	reactionListFull = cobraModel.reactions[:]

	for key in reactionListFull:
		if 'EX_' in key:
			data[key.id] = None

	with open('../data/Ignore Set/' + fileName, 'w') as handle:
		json.dump(data, handle, sort_keys=True, indent=4)

def pool(noOfProcesses, fileName):
	p = Pool(processes = noOfProcesses)
	p.map(worker, fileName)

if __name__ == '__main__':
	print("Pool started!")
	pool(8, listDir)