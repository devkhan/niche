import cobra.io, json
from cobra.solvers import solver_dict, get_solver_name

def triple_reaction_deletion(**solver_args):
	model = cobra.io.load_json_model('../models/iNJ661_Mycobacterium_Tuberculosis_H37Rv.json')
	solver = solver_dict[get_solver_name()]
	lp = solver.create_problem(model)

	reaction1 = model.reactions.get_by_id("PHDCAt")
	old_bounds1 = (reaction1.lower_bound, reaction1.upper_bound)
	index1 = model.reactions.index(reaction1)
	solver.change_variable_bounds(lp, index1, 0., 0.)
	solver.solve_problem(lp, **solver_args)

	reaction2 = model.reactions.get_by_id("TKT2")
	old_bounds2 = (reaction2.lower_bound, reaction2.upper_bound)
	index2 = model.reactions.index(reaction2)
	solver.change_variable_bounds(lp, index2, 0., 0.)
	solver.solve_problem(lp, **solver_args)

	reaction3 = model.reactions.get_by_id("GLCabc")
	old_bounds3 = (reaction3.lower_bound, reaction3.upper_bound)
	index3 = model.reactions.index(reaction3)
	solver.change_variable_bounds(lp, index3, 0., 0.)

	solver.solve_problem(lp, **solver_args)
	status = solver.get_status(lp)
	print(solver.get_objective_value(lp), status)

	# reset the problem
	solver.change_variable_bounds(lp, index3, old_bounds3[0], old_bounds3[1])
	solver.change_variable_bounds(lp, index2, old_bounds2[0], old_bounds2[1])
	solver.change_variable_bounds(lp, index1, old_bounds1[0], old_bounds1[1])

triple_reaction_deletion()